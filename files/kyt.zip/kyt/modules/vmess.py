from kyt import *
import asyncio
import os
import subprocess
from datetime import datetime

CONFIG_FILE = "/etc/xray/config.json"
ACCESS_LOG = "/var/log/xray/access.log"


# =============================
# CEK USER ONLINE VMESS
# =============================
@bot.on(events.CallbackQuery(data=b'check-online-vmess'))
async def check_online_vmess(event):
    await event.delete()
    try:
        # Ambil semua user dari config.json (tag ### user exp)
        result = subprocess.run(f"grep '^###' {CONFIG_FILE} | awk '{{print $2}}'",
                                shell=True, text=True, capture_output=True)
        users = [u for u in result.stdout.strip().split("\n") if u]

        if not users:
            await event.respond("⚠️ Tidak ada user Vmess.")
            return

        msg = "📶 **User Vmess Online:**\n\n"
        for user in users:
            # Ambil IP yang login
            cmd_ip = f"grep -w '{user}' {ACCESS_LOG} | tail -n 500 | awk '{{print $3}}' | sed 's/tcp://g' | cut -d ':' -f1 | sort -u"
            ips_result = subprocess.run(cmd_ip, shell=True, text=True, capture_output=True)
            ips = [ip for ip in ips_result.stdout.strip().split("\n") if ip]

            # Ambil last login
            cmd_last = f"grep -w '{user}' {ACCESS_LOG} | tail -n 500 | awk '{{print $2}}' | tail -1"
            last_result = subprocess.run(cmd_last, shell=True, text=True, capture_output=True)
            last_login = last_result.stdout.strip() or "-"

            if ips:
                msg += f"👤 **{user}**\n"
                msg += f"• Last Login: {last_login}\n"
                msg += f"• IP Active: {len(ips)} → {', '.join(ips)}\n\n"

        buttons = [[Button.inline("⬅️ Kembali", data=b'vmess')]]
        await event.respond(msg, buttons=buttons)

    except Exception as e:
        await event.respond(f"⚠️ Error saat cek user online: `{str(e)}`")


# =============================
# CREATE VMESS
# =============================
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as conv:
            await event.respond("**Username:**")
            res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = res.raw_text.strip()

        async with bot.conversation(chat) as conv:
            await event.respond("**Quota (GB):**")
            res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            quota = res.raw_text.strip()
            if not quota.isdigit():
                return await event.respond("❌ Input quota harus angka!")

        async with bot.conversation(chat) as conv:
            await event.respond("**Expired (Hari):**")
            res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = res.raw_text.strip()
            if not exp.isdigit():
                return await event.respond("❌ Input expired harus angka!")

        # Loading
        for txt in ["Processing.", "Processing..", "Processing...", "Processing...."]:
            await event.edit(txt)
            await asyncio.sleep(1)

        await event.edit("`Membuat akun VMess...`")
        await asyncio.sleep(2)

        # Jalankan addws
        cmd = f'printf "%s\n" "{username}" "{exp}" "{quota}" | addws'
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            return await event.respond("❌ User sudah ada!")

        # Ambil config VMESS
        b = [x.group() for x in re.finditer("vmess://(.*)", output)]
        z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("ascii"))

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        # Notifikasi singkat
        await event.respond(f"✅ Akun VMess `{username}` berhasil dibuat")
        await asyncio.sleep(3)

        # Notifikasi detail
        msg = f"""
**━━━━━━━━━━━━━━━━━**
**🇮🇩 BOT - Xray/Vmess 🇮🇩**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `{quota} GB`
**» Ports        :** TLS `222-1000`, NTLS `80,8080`, GRPC `443`
**» User ID      :** `{z["id"]}`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `/vmess`
**» Path NTLS    :** `/vmess`
**» ServiceName  :** `vmess-grpc`
**» Pub Key      :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**» Link TLS     :** 
`{b[0].strip()}`

**» Link NTLS    :** 
`{b[1].strip()}`

**» Link GRPC    :** 
`{b[2].strip()}`
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


# =============================
# TRIAL VMESS
# =============================
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        async with bot.conversation(chat) as conv:
            await event.respond("**Expired (Menit):**")
            res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = res.raw_text.strip()
            if not exp.isdigit():
                return await event.respond("❌ Input expired harus angka!")

        # Loading
        for txt in ["Processing.", "Processing..", "Processing...", "Processing...."]:
            await event.edit(txt)
            await asyncio.sleep(1)

        await event.edit("`Membuat akun VMess Trial...`")
        await asyncio.sleep(2)

        # Jalankan trialws
        cmd = f'printf "%s\n" "{exp}" | trialws'
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            return await event.respond("❌ Gagal membuat akun!")

        # Ambil link vmess:// dari output
        b = [x.group() for x in re.finditer("vmess://(.*)", output)]
        if len(b) < 3:
            return await event.respond("❌ Gagal parsing link VMess (trialws tidak mengembalikan link).")

        try:
            z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("ascii"))
        except Exception as e:
            return await event.respond(f"❌ Error decode vmess: {e}")

        # Ambil waktu CREATED & EXPIRED dari output trialws
        created = "-"
        expired = "-"
        for line in output.splitlines():
            if line.startswith("CREATED:"):
                created = line.replace("CREATED:", "").strip()
            if line.startswith("EXPIRED:"):
                expired = line.replace("EXPIRED:", "").strip()

        # Notifikasi singkat
        await event.respond("✅ Trial VMess berhasil dibuat")
        await asyncio.sleep(3)

        # Notifikasi detail
        msg = f"""
**━━━━━━━━━━━━━━━━━**
    **⭐ XRAY / VMESS Trial ⭐**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `Unlimited`
**» Ports        :** TLS `222-1000`, NTLS `80,8080`, GRPC `443`
**» User ID      :** `{z["id"]}`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `/vmess`
**» Path NTLS    :** `/vmess`
**» ServiceName  :** `vmess-grpc`
**» Pub Key      :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**» Link TLS     :** 
`{b[0].strip()}`

**» Link NTLS    :** 
`{b[1].strip()}`

**» Link GRPC    :** 
`{b[2].strip()}`
**━━━━━━━━━━━━━━━━━**
**» Dibuat Pada  :** `{created}`
**» Expired Pada :** `{expired}`
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


# =============================
# LIST AKUN VMESS (sinkron config.json)
# =============================
@bot.on(events.CallbackQuery(data=b'list-vmess'))
async def list_vmess(event):
    try:
        await event.delete()
        cmd = f"grep '^###' {CONFIG_FILE} | awk '{{print $2\"|\"$3\" \"$4}}'"
        result = subprocess.run(cmd, shell=True, text=True, capture_output=True)
        lines = [line.strip() for line in result.stdout.split("\n") if line.strip()]

        if not lines:
            await event.respond("⚠️ Tidak ada akun Vmess ditemukan.")
            return

        msg = "📋 **Daftar Akun Vmess:**\n\n"
        for line in lines:
            parts = line.split("|")
            user = parts[0]
            exp = parts[1].strip()
            msg += f"• {user} | Exp: {exp}\n"

        buttons = [[Button.inline("⬅️ Kembali", data=b'vmess')]]
        await event.respond(msg, buttons=buttons)

    except Exception as e:
        await event.respond(f"⚠️ Error saat ambil daftar user: `{str(e)}`")




# =============================
# DELETE USER VMESS
# =============================
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def show_vmess_list(event):
    try:
        await event.delete()
        cmd = (
    f'exp=$(grep -wE \"^### {username}\" {CONFIG_FILE} | awk \"{{print $3 \\\" \\\" $4}}\") '
    f'&& sed -i \"/^### {username} $exp/,/^}},/d\" {CONFIG_FILE} '
    f'&& systemctl restart xray '
    f'&& echo \"User {username} deleted\"'
)


        if not users:
            await event.respond("⚠️ Tidak ada akun Vmess ditemukan.")
            return

        buttons = [[Button.inline(f"❌ {user}", data=f"delete-vmess:{user}".encode())] for user in users]
        buttons.append([Button.inline("🔙 Batal", data=b"cancel-delete-vmess")])

        await event.respond("📋 **Daftar Akun Vmess:**", buttons=buttons)

    except Exception as e:
        await event.respond(f"⚠️ Error saat ambil daftar user: `{str(e)}`")


@bot.on(events.CallbackQuery(pattern=b'delete-vmess:(.+)'))
async def delete_selected_vmess(event):
    try:
        await event.delete()
        username = event.pattern_match.group(1).decode()

        cmd = (
            f'exp=$(grep -wE \"^### {username}\" {CONFIG_FILE} | awk \"{{print $3}}\") '
            f'&& sed -i \"/^### {username} $exp/,/^}},/d\" {CONFIG_FILE} '
            f'&& systemctl restart xray '
            f'&& echo \"User {username} deleted\"'
        )
        result = subprocess.run(cmd, shell=True, text=True, capture_output=True)
        output = result.stdout.strip() or result.stderr.strip() or "Selesai"

        msg = f"✅ Akun **{username}** berhasil dihapus.\n\n📄 Log:\n`{output}`"
        buttons = [[Button.inline("⬅️ Kembali", data=b'delete-vmess')]]
        await event.respond(msg, buttons=buttons)

    except Exception as e:
        await event.respond(f"⚠️ Error saat hapus user: `{str(e)}`")


@bot.on(events.CallbackQuery(data=b'cancel-delete-vmess'))
async def cancel_delete_vmess(event):
    await event.delete()
    buttons = [[Button.inline("⬅️ Kembali", data=b'vmess')]]
    await event.respond("❎ Penghapusan akun dibatalkan.", buttons=buttons)


# =============================
# MENU UTAMA VMESS
# =============================
@bot.on(events.CallbackQuery(data=b'vmess'))
async def menu_vmess(event):
    sender = await event.get_sender()
    if valid(str(sender.id)).lower() != "true":
        await event.answer("Access Denied", alert=True)
        return

    buttons = [
        [Button.inline("➕ Create Akun", data=b'create-vmess')],
        [Button.inline("⏱ Trial Akun", data=b'trial-vmess'), Button.inline("📋 List Akun", data=b'list-vmess')],
        [Button.inline("📶 Check Online", data=b'check-online-vmess'), Button.inline("❌ Delete Akun", data=b'delete-vmess')],
        [Button.inline("🔙 Kembali ke Menu Utama", data=b'menu')]
    ]

    try:
        try:
            await event.message.delete()
        except:
            pass

        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        except:
            z = {"isp":"Unknown","country":"Unknown"}

        header_msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🇮🇩 LORDFREEDOM TUNNELING 🇮🇩**
━━━━━━━━━━━━━━━━━━━━━━━ 
                  ** ⭐ VMESS ⭐**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **Service :** `VMESS`
🔰 **Hostname/IP :** `{DOMAIN}`
🔰 **ISP :** `{z['isp']}`
🔰 **Country :** `{z['country']}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.respond(header_msg, buttons=buttons)

    except Exception as e:
        await event.respond(f"⚠️ Terjadi error: {str(e)}", buttons=buttons)
