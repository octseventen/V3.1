from kyt import *
import asyncio
import os
import subprocess
from datetime import datetime

@bot.on(events.CallbackQuery(data=b'check-online-vmess'))
async def check_online_vmess(event):
    await event.delete()
    try:
        # Ambil semua user dari config.json
        db_file = "/etc/xray/config.json"
        result = subprocess.run(f"grep '###' {db_file} | cut -d ' ' -f 2 | sort | uniq",
                                shell=True, text=True, capture_output=True)
        users = [u for u in result.stdout.strip().split("\n") if u]

        if not users:
            await event.respond("⚠️ Tidak ada user Vmess.")
            return

        msg = "📶 **User Vmess Online:**\n\n"
        for user in users:
            # Ambil IP yang login
            cmd_ip = f"grep -w '{user}' /var/log/xray/access.log | tail -n 500 | awk '{{print $3}}' | sed 's/tcp://g' | cut -d ':' -f1 | sort | uniq"
            ips_result = subprocess.run(cmd_ip, shell=True, text=True, capture_output=True)
            ips = [ip for ip in ips_result.stdout.strip().split("\n") if ip]

            # Ambil last login
            cmd_last = f"grep -w '{user}' /var/log/xray/access.log | tail -n 500 | awk '{{print $2}}' | tail -1"
            last_result = subprocess.run(cmd_last, shell=True, text=True, capture_output=True)
            last_login = last_result.stdout.strip() or "-"

            if ips:
                msg += f"👤 **{user}**\n"
                msg += f"• Last Login: {last_login}\n"
                msg += f"• IP Active: {len(ips)} → {', '.join(ips)}\n\n"

        # Tombol kembali ke menu Vmess
        buttons = [[Button.inline("⬅️ Kembali ke Menu Vmess", data=b'menu-vmess')]]
        await event.respond(msg, buttons=buttons)

    except Exception as e:
        await event.respond(f"⚠️ Error saat cek user online: `{str(e)}`")

# =============================
# CREATE VMESS
# =============================
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        # Username
        async with bot.conversation(chat) as conv:
            await event.respond("**Username:**")
            res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = res.raw_text.strip()

        # Quota
        async with bot.conversation(chat) as conv:
            await event.respond("**Quota (GB):**")
            res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            quota = res.raw_text.strip()
            if not quota.isdigit():
                return await event.respond("❌ Input quota harus angka!")

        # Expired
        async with bot.conversation(chat) as conv:
            await event.respond("**Expired (Hari):**")
            res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = res.raw_text.strip()
            if not exp.isdigit():
                return await event.respond("❌ Input expired harus angka!")

        # Loading effect
        for txt in ["Processing.", "Processing..", "Processing...", "Processing...."]:
            await event.edit(txt)
            await asyncio.sleep(1)

        await event.edit("`Membuat akun VMess...`")
        await asyncio.sleep(2)

        # Eksekusi perintah addws
        cmd = f'printf "%s\n" "{username}" "{exp}" "{quota}" | addws'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            return await event.respond("❌ User sudah ada!")

        # Ambil config
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("ascii"))

        # Notifikasi singkat
        await event.respond(f"✅ Akun VMess `{username}` berhasil dibuat")
        await asyncio.sleep(3)

        # Notifikasi detail
        msg = f"""
**━━━━━━━━━━━━━━━━━**
**🇮🇩 Xray/Vmess Premium 🇮🇩**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `{quota} GB`
**» Ports        :** TLS `222-1000`, NTLS `80,8080`, GRPC `443`
**» User ID      :** `{z["id"]}`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `/vmess`
**» Path NTLS    :** `/vmess`
**» ServiceName  :** `vmess-grpc`
**» Pub Key      :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**» Link TLS     :** 
`{b[0].strip()}`

**» Link NTLS    :** 
`{b[1].strip()}`

**» Link GRPC    :** 
`{b[2].strip()}`
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash :** https://{DOMAIN}:81/vmess-{username}.txt
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
"""
        await event.respond(msg)
            
            # Simpan ke database member-vmess
        with open("/etc/xray/member-vmess", "a") as f:
            f.write(f"{username}|{quota}|{later}\n")

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


# =============================
# TRIAL VMESS
# =============================
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        # Expired (menit)
        async with bot.conversation(chat) as conv:
            await event.respond("**Expired (Menit):**")
            res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = res.raw_text.strip()
            if not exp.isdigit():
                return await event.respond("❌ Input expired harus angka!")

        # Loading
        for txt in ["Processing.", "Processing..", "Processing...", "Processing...."]:
            await event.edit(txt)
            await asyncio.sleep(1)

        await event.edit("`Membuat akun VMess Trial...`")
        await asyncio.sleep(2)

        # Eksekusi perintah trialws
        cmd = f'printf "%s\n" "{exp}" | trialws'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            return await event.respond("❌ Gagal membuat akun!")

        # Ambil config
        now = DT.datetime.now()
        later = now + DT.timedelta(minutes=int(exp))
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]
        z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("ascii"))

        # Notifikasi singkat
        await event.respond("✅ Trial VMess berhasil dibuat")
        await asyncio.sleep(3)

        # Notifikasi detail
        msg = f"""
**━━━━━━━━━━━━━━━━━**
    **⭐ XRAY / VMESS Trial ⭐**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `Unlimited`
**» Ports        :** TLS `222-1000`, NTLS `80,8080`, GRPC `443`
**» User ID      :** `{z["id"]}`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `/vmess`
**» Path NTLS    :** `/vmess`
**» ServiceName  :** `vmess-grpc`
**» Pub Key      :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**» Link TLS     :** 
`{b[0].strip()}`

**» Link NTLS    :** 
`{b[1].strip()}`

**» Link GRPC    :** 
`{b[2].strip()}`
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash :** https://{DOMAIN}:81/vmess-{z["ps"]}.txt
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later.strftime("%d-%m-%Y %H:%M:%S")}`
"""
        await event.respond(msg)
            # Simpan ke database m-vmess
        with open("/etc/xray/m-vmess", "a") as f:
            f.write(f"{z['ps']}|unlimited|{later.strftime('%Y-%m-%d %H:%M:%S')}\n")

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# =============================
# CEK VMESS
# =============================
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
   async def cek_vmess_(event):
    cmd = 'bot-cek-ws'.strip()
    try:
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    except subprocess.CalledProcessError as e:
        output = e.output or "❌ Gagal cek user VMess."

    if not output.strip():
        output = "⚠️ Tidak ada user VMess yang sedang online."

    await event.respond(f"""
{output}

**👤 Logged In Users VMess**
━━━━━━━━━━━━━━━━━━━━
""", buttons=[[Button.inline("‹ Main Menu ›","menu")]])

db_file = "/etc/xray/member-vmess"
# === MENU DELETE VMESS ===
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def show_vmess_list(event):
    try:
        await event.delete()

        if not os.path.exists(db_file):
            await event.respond("⚠️ Database member-vmess tidak ditemukan.")
            return

        with open(db_file, "r") as f:
            lines = [line.strip() for line in f if line.strip()]

        if not lines:
            await event.respond("⚠️ Tidak ada akun Vmess ditemukan (file kosong).")
            return

        users = [line.split("|")[0] for line in lines]

        # Buat tombol per user
        buttons = []
        for user in users:
            buttons.append([Button.inline(f"❌ {user}", data=f"delete-vmess:{user}".encode())])

        # Tombol batal
        buttons.append([Button.inline("🔙 Batal", data=b"cancel-delete-vmess")])

        await event.respond("📋 **Daftar Akun Vmess:**", buttons=buttons)

    except Exception as e:
        await event.respond(f"⚠️ Error saat ambil daftar user: `{str(e)}`")


# === DELETE USER SIMPEL ===
@bot.on(events.CallbackQuery(pattern=b'delete-vmess:(.+)'))
async def delete_selected_vmess(event):
    try:
        await event.delete()

        username = event.pattern_match.group(1).decode()

        # Jalankan hapus user langsung (mirip delws)
        cmd = (
            f'exp=$(grep -wE "^### {username}" /etc/xray/config.json | cut -d " " -f 3 | sort | uniq) '
            f'&& sed -i "/^### {username} $exp/,/^}},/d" /etc/xray/config.json '
            f'&& systemctl restart xray '
            f'&& echo "User {username} deleted"'
        )
        result = subprocess.run(cmd, shell=True, text=True, capture_output=True)
        output = result.stdout.strip() or result.stderr.strip() or "Selesai"

        # Hapus user dari database member-vmess
        if os.path.exists(db_file):
            with open(db_file, "r") as f:
                lines = f.readlines()
            with open(db_file, "w") as f:
                for line in lines:
                    if not line.startswith(username + "|"):
                        f.write(line)

        msg = f"✅ Akun **{username}** berhasil dihapus.\n\n📄 Log:\n`{output}`"

        buttons = [[Button.inline("⬅️ Kembali", data=b'delete-vmess')]]
        await event.respond(msg, buttons=buttons)

    except Exception as e:
        await event.respond(f"⚠️ Error saat hapus user: `{str(e)}`")


# === BATALKAN DELETE ===
@bot.on(events.CallbackQuery(data=b'cancel-delete-vmess'))
async def cancel_delete_vmess(event):
    try:
        await event.delete()
        buttons = [[Button.inline("⬅️ Kembali", data=b'menu-vmess')]]
        await event.respond("❎ Penghapusan akun dibatalkan.", buttons=buttons)
    except Exception as e:
        await event.respond(f"⚠️ Error saat batal: `{str(e)}`")

# === LIST AKUN VMESS ===
@bot.on(events.CallbackQuery(data=b'list-vmess'))
async def list_vmess(event):
    try:
        await event.delete()

        if not os.path.exists(db_file):
            await event.respond("⚠️ Database member-vmess tidak ditemukan.")
            return

        with open(db_file, "r") as f:
            lines = [line.strip() for line in f if line.strip()]

        if not lines:
            await event.respond("⚠️ Tidak ada akun Vmess ditemukan.")
            return

        msg = "📋 **Daftar Akun Vmess:**\n\n"
        for line in lines:
            user, quota, exp = line.split("|")
            msg += f"• {user} | Quota: {quota} | Exp: {exp}\n"

        buttons = [[Button.inline("⬅️ Kembali", data=b'vmess')]]
        await event.respond(msg, buttons=buttons)

    except Exception as e:
        await event.respond(f"⚠️ Error saat ambil daftar user: `{str(e)}`")

# === MENU UTAMA VMESS ===
@bot.on(events.CallbackQuery(data=b'vmess'))
async def menu_vmess(event):
    sender = await event.get_sender()

    # Cek akses user
    if valid(str(sender.id)).lower() != "true":
        await event.answer("Access Denied", alert=True)
        return

    # Definisikan tombol menu
    buttons = [
        [Button.inline("➕ Create Akun", data=b'create-vmess')],
        [Button.inline("⏱ Trial Akun", data=b'trial-vmess'), Button.inline("📋 List Akun", data=b'list-vmess')],
        [Button.inline("📶 Check Online", data=b'check-online-vmess'), Button.inline("❌ Delete Akun", data=b'delete-vmess')],
        [Button.inline("🔙 Kembali ke Menu Utama", data=b'menu')]
    ]

    try:
        # Hapus pesan callback lama
        await event.delete()

        # Kirim pesan menu baru
        await event.respond("📌 **Menu Vmess**:", buttons=buttons)

    except Exception as e:
        # Jika terjadi error, tampilkan info server
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        except:
            z = {"isp":"Unknown","country":"Unknown"}

        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🇮🇩 LORDFREEDOM TUNNELING 🇮🇩**
━━━━━━━━━━━━━━━━━━━━━━━ 
                  ** ⭐ VMESS ⭐**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **Service :** `VMESS`
🔰 **Hostname/IP :** `{DOMAIN}`
🔰 **ISP :** `{z['isp']}`
🔰 **Country :** `{z['country']}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.respond(msg, buttons=buttons)
