from kyt import *
import asyncio
import subprocess
import time
import random
import datetime as DT
import requests
import base64
import json
import re
from telethon import events, Button

# CREATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond("**Username:**")
        username = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

    async with bot.conversation(chat) as conv:
        await event.respond("**Quota (GB):**")
        quota = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

    async with bot.conversation(chat) as conv:
        await event.respond("**Limit IP:**")
        limitip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

    async with bot.conversation(chat) as conv:
        await event.respond("**Expiry Times (days):**")
        exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

    for step in ["0%", "8%", "20%", "52%", "84%", "100%"]:
        filled = '█' * (int(step[:-1]) // 4)
        empty = '▒' * (25 - len(filled))
        await event.edit(f"**Processing... {step}\n{filled}{empty}**")
        time.sleep(1)

    await event.edit("**Wait.. Setting up an Account**")
    cmd = f'printf "%s\n" "{username}" "{exp}" "{quota}" "{limitip}" | addws'
    try:
        output = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except subprocess.CalledProcessError:
        await event.respond("**User Already Exist**")
        return

    expired_date = DT.date.today() + DT.timedelta(days=int(exp))
    b = [x.group() for x in re.finditer("vmess://(.*)", output)]

    z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("ascii"))
    z1 = json.loads(base64.b64decode(b[1].replace("vmess://", "")).decode("ascii"))

    msg = f"""
**✅ XRAY / VMESS ACCOUNT ✅**
━━━━━━━━━━━━━━━━━━
👤 **Username:** `{z['ps']}`
🌐 **Domain:** `{z['add']}`
🛡️ **DNS Host:** `{HOST}`
📊 **Quota:** `{quota} GB`
📶 **Limit IP:** `{limitip}`
━━━━━━━━━━━━━━━━━━
**Ports:**
• DNS: 443, 53
• TLS: 222-1000
• NTLS: 80, 8080, 8081-9999
• GRPC: 443
━━━━━━━━━━━━━━━━━━
**User ID:** `{z['id']}`
**Network:** `WS / gRPC`
**Security:** `auto`
**Path TLS:** `/vmess`
**ServiceName:** `vmess-grpc`
**PubKey:** `{PUB}`
━━━━━━━━━━━━━━━━━━
**Link TLS:**
```{b[0]}```
━━━━━━━━━━━━━━━━━━
**Link NTLS:**
```{b[1]}```
━━━━━━━━━━━━━━━━━━
**Link GRPC:**
```{b[2]}```
━━━━━━━━━━━━━━━━━━
📦 **OpenClash Config:**
https://{DOMAIN}:81/vmess-{username}.txt
⏳ **Expired:** {expired_date}
"""
    await event.respond(msg)

# VMESS MENU
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    inline = [
        [Button.inline("TRIAL VMESS", b'trial-vmess'), Button.inline("CREATE VMESS", b'create-vmess')],
        [Button.inline("LIST USER", b'show-vmess'), Button.inline("ONLINE USER", b'online-vmess')],
        [Button.inline("DELETE VMESS", b'delete-vmess')],
        [Button.inline("‹ Main Menu ›", b'menu')]
    ]

    z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🇮🇩 LORDFREEDOM TUNNELING 🇮🇩**
━━━━━━━━━━━━━━━━━━━━━━━ 
**⭐ VMESS PANEL**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **Service:** `VMESS`
🔰 **Host/IP:** `{DOMAIN}`
🔰 **ISP:** `{z['isp']}`
🔰 **Country:** `{z['country']}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg, buttons=inline)

# SHOW VMESS USERS
@bot.on(events.CallbackQuery(data=b'show-vmess'))
async def show_vmess(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
    cmd = 'cat /etc/xray/vmess.txt'  # ganti sesuai lokasi file
    try:
        users = subprocess.check_output(cmd, shell=True).decode()
        await event.respond(f"**📋 List User VMESS:**\n<pre>{users}</pre>", parse_mode='html')
    except:
        await event.respond("Gagal mengambil data user.")

# SHOW ONLINE VMESS USERS
@bot.on(events.CallbackQuery(data=b'online-vmess'))
async def online_vmess(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
    cmd = 'bot-cek-ws'  # ganti dengan script pengecekan online user
    try:
        online = subprocess.check_output(cmd, shell=True).decode()
        await event.respond(f"**🟢 Online User VMESS:**\n<pre>{online}</pre>", parse_mode='html')
    except:
        await event.respond("Gagal cek online user.")
