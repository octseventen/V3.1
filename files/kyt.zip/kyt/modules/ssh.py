from kyt import *
import asyncio
import subprocess
import time
import random
import datetime as DT
import os
import requests
from telethon import events, Button

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond("🧾 Masukkan Username:")
        username = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("🔐 Masukkan Password:")
        password = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("🌐 Limit IP Login:")
        iplimit = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("💾 Limit Kuota (GB):")
        quota_gb = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("⏳ Masa aktif (hari):")
        aktif_hari = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

    await event.respond("⏳ Membuat akun, harap tunggu...")

    # Ambil domain dan IP VPS
    try:
        with open("/etc/xray/domain", "r") as f:
            domain = f.read().strip()
        ipvps = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode().strip()
    except:
        domain = "unknown"
        ipvps = "0.0.0.0"

    # Tanggal
    now = DT.datetime.now()
    tgl_buat = now.strftime("%d %b %Y")
    tgl_exp = (now + DT.timedelta(days=int(aktif_hari))).strftime("%d %b %Y")
    expired_date = (now + DT.timedelta(days=int(aktif_hari))).strftime("%Y-%m-%d")  # untuk useradd

    # Buat akun
    try:
        subprocess.run(f"useradd -e {expired_date} -s /bin/false -M {username}", shell=True, check=True)
        subprocess.run(f"echo -e '{password}\n{password}' | passwd {username}", shell=True, check=True)
    except subprocess.CalledProcessError as e:
        await event.respond(f"❌ Username `{username}` sudah terdaftar atau gagal dibuat.\nError: {e}")
        return

    # Simpan IP limit
    os.makedirs("/etc/kyt/limit/ssh/ip", exist_ok=True)
    if iplimit.isdigit() and int(iplimit) > 0:
        with open(f"/etc/kyt/limit/ssh/ip/{username}", "w") as f:
            f.write(iplimit)

    # Simpan quota (dalam byte)
    try:
        quota_byte = int(quota_gb) * 1024 * 1024 * 1024
    except:
        quota_byte = 0

    if quota_byte > 0:
        os.makedirs("/etc/ssh", exist_ok=True)
        with open(f"/etc/ssh/{username}", "w") as f:
            f.write(str(quota_byte))

    # Auto delete user dengan at
    subprocess.run(f"echo 'userdel -f {username}' | at now + {aktif_hari} days", shell=True)

    # Simpan ke database
    subprocess.run(f"sed -i '/\\b{username}\\b/d' /etc/ssh/.ssh.db", shell=True)
    with open("/etc/ssh/.ssh.db", "a") as f:
        f.write(f"#ssh# {username} {password} {quota_gb} {iplimit} {tgl_exp}\n")

    # Format pesan laporan
    text = f"""◇━━━━━━━━━━━━━━━━━◇
 Format SSH OVPN Account
◇━━━━━━━━━━━━━━━━━◇
Username         : {username}
Password         : {password}
Limit IP         : {iplimit}
Limit Kuota      : {quota_gb} GB
IP VPS           : {ipvps}
Domain           : {domain}
Port SSH         : 22, 80, 443
Dropbear         : 109, 143
SSL/TLS          : 443, 400-900
SSH WS           : 80, 8080, 8081-9999
SSH WS SSL       : 443
OVPN WS SSL      : 443
OVPN TCP         : 1194
OVPN UDP         : 2200
BadVPN UDP       : 7100, 7200, 7300
◇━━━━━━━━━━━━━━━━━◇
Aktif Selama     : {aktif_hari} Hari
Dibuat Pada      : {tgl_buat}
Berakhir Pada    : {tgl_exp}
◇━━━━━━━━━━━━━━━━━◇
OVPN Download    : https://{domain}:81/
Save Link        : https://{domain}:81/ssh-{username}.txt
"""

    await event.respond(f"<code>{text}</code>", parse_mode="html")


    msg = f"""
◇━━━━━━━━━━━━━━━━━━━━━━◇
   🇮🇩 <b>SSH/OPENVPN MENU</b> 🇮🇩
◇━━━━━━━━━━━━━━━━━━━━━━◇
🔰 <b>Service</b>: SSH & OVPN
🌐 <b>Hostname/IP</b>: <code>{domain}</code>
🏢 <b>ISP</b>: {z['isp']}
🌍 <b>Country</b>: {z['country']}
◇━━━━━━━━━━━━━━━━━━━━━━◇
"""

    tombol = [
        [Button.inline("⚡ TRIAL SSH", b"trial-ssh"), Button.inline("➕ CREATE SSH", b"create-ssh")],
        [Button.inline("❌ DELETE SSH", b"delete-ssh"), Button.inline("👀 CHECK LOGIN", b"login-ssh")],
        [Button.inline("📋 SHOW USER", b"show-ssh")],
        [Button.inline("🔙 Main Menu", b"menu")]
    ]

    await event.edit(msg, buttons=tombol, parse_mode="html")
