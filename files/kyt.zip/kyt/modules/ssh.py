from kyt import *
import asyncio
import subprocess
import time
import random
import datetime as DT
import os
import re
import requests
from telethon import events, Button

#MENU SSH
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh_menu(event):
    sender = await event.get_sender()

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    try:
        with open("/etc/xray/domain", "r") as f:
            domain = f.read().strip()
    except:
        domain = "domain.tidak.terdeteksi"
    msg = f"""
◇━━━━━━━━━━━━━━━━━━━━━━◇
   🇮🇩 <b>SSH/OPENVPN MENU</b> 🇮🇩
◇━━━━━━━━━━━━━━━━━━━━━━◇
🔰 <b>Service</b>: SSH & OVPN
🌐 <b>Hostname/IP</b>: <code>{domain}</code>
🏢 <b>ISP</b>: {z['isp']}
🌍 <b>Country</b>: {z['country']}
◇━━━━━━━━━━━━━━━━━━━━━━◇
"""

    tombol = [
        [Button.inline("⚡ TRIAL SSH", b"trial-ssh"), Button.inline("➕ CREATE SSH", b"create-ssh")],
        [Button.inline("❌ DELETE SSH", b"delete-ssh"), Button.inline("👀 CHECK LOGIN", b"login-ssh")],
        [Button.inline("📋 SHOW USER", b"show-ssh")],
        [Button.inline("🔙 Main Menu", b"menu")]
    ]

    await event.edit(msg, buttons=tombol, parse_mode="html")
#MENU TRIAL
@bot.on(events.CallbackQuery(data=b"trial-ssh"))
async def trial_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond("🕐 Masukkan Durasi Trial (menit):")
        menit = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

    try:
        menit_int = int(menit)
        if menit_int <= 0 or menit_int > 1440:
            raise ValueError
    except:
        await event.respond("❌ Durasi harus angka (1–1440 menit).")
        return

    # Auto generate username & password
    rand_suffix = random.randint(1000, 9999)
    username = f"Trial-{rand_suffix}"
    password = "1"

    # Tanggal & expired
    now = DT.datetime.now()
    expired_time = now + DT.timedelta(minutes=menit_int)
    tgl_exp = expired_time.strftime("%H:%M:%S %d-%b-%Y")

    # Ambil domain & IP
    try:
        domain = open("/etc/xray/domain").read().strip()
        ipvps = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    except:
        domain = "unknown"
        ipvps = "0.0.0.0"

    try:
        subprocess.run(f"useradd -e {expired_time.strftime('%Y-%m-%d')} -s /bin/false -M {username}", shell=True, check=True)
        subprocess.run(f"echo '{username}:{password}' | chpasswd", shell=True, check=True)
    except Exception as e:
        await event.respond(f"❌ Gagal membuat akun `{username}`.\nError: {e}")
        return

    # Auto delete by at
    subprocess.run(f"echo 'userdel -f {username}' | at now + {menit_int} minutes", shell=True)

    # Simpan ke log database trial (opsional)
    with open("/etc/ssh/.ssh.db", "a") as f:
        f.write(f"#trial# {username} {password} {tgl_exp}\n")

    # Kirim laporan
    msg = f"""◇━━━━━━━━━━━━━━━━◇
 Trial SSH Account
◇━━━━━━━━━━━━━━━━◇
Username   : {username}
Password   : {password}
IP VPS     : {ipvps}
Domain     : {domain}
Ports      : 22, 80, 443, 109, 143, 1194, 2200
Aktif s/d  : {tgl_exp}
Durasi     : {menit_int} menit
◇━━━━━━━━━━━━━━━━◇"""

    await event.respond(f"<code>{msg}</code>", parse_mode="html")

#CREATE SSH
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond("🧾 Masukkan Username:")
        username = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        # Validasi username
        if not re.match("^[a-zA-Z][a-zA-Z0-9_-]{2,15}$", username):
            await event.respond("❌ Username tidak valid. Harus diawali huruf, 3–16 karakter, hanya a-z, 0-9, -, _")
            return

        # Cek user sudah ada
        if subprocess.run(f"id -u {username}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
            await event.respond(f"❌ Username `{username}` sudah terdaftar.")
            return

        await conv.send_message("🔐 Masukkan Password:")
        password = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("🌐 Limit IP Login:")
        iplimit = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("💾 Limit Kuota (GB):")
        quota_gb = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("⏳ Masa aktif (hari):")
        aktif_hari = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

    await event.respond("⏳ Membuat akun, harap tunggu...")

    # Ambil domain dan IP
    try:
        with open("/etc/xray/domain", "r") as f:
            domain = f.read().strip()
        ipvps = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode().strip()
    except:
        domain = "unknown"
        ipvps = "0.0.0.0"

    now = DT.datetime.now()
    tgl_buat = now.strftime("%d %b %Y")
    tgl_exp = (now + DT.timedelta(days=int(aktif_hari))).strftime("%d %b %Y")
    expired_date = (now + DT.timedelta(days=int(aktif_hari))).strftime("%Y-%m-%d")

    # Buat user
    try:
        subprocess.run(f"useradd -e {expired_date} -s /bin/false -M {username}", shell=True, check=True)
    except subprocess.CalledProcessError as e:
        await event.respond(f"❌ Gagal membuat akun `{username}`.\nError: {e}")
        return

    # Set password pakai chpasswd
    try:
        subprocess.run(f"echo '{username}:{password}' | chpasswd", shell=True, check=True)
    except subprocess.CalledProcessError as e:
        subprocess.run(f"userdel -f {username}", shell=True)
        await event.respond(f"❌ Gagal mengatur password. Akun `{username}` dibatalkan.\nError: {e}")
        return

    # Simpan IP limit
    os.makedirs("/etc/kyt/limit/ssh/ip", exist_ok=True)
    if iplimit.isdigit() and int(iplimit) > 0:
        with open(f"/etc/kyt/limit/ssh/ip/{username}", "w") as f:
            f.write(iplimit)

    # Simpan quota
    try:
        quota_byte = int(quota_gb) * 1024 * 1024 * 1024
    except:
        quota_byte = 0

    if quota_byte > 0:
        os.makedirs("/etc/ssh", exist_ok=True)
        with open(f"/etc/ssh/{username}", "w") as f:
            f.write(str(quota_byte))

    # Auto delete
    subprocess.run(f"echo 'userdel -f {username}' | at now + {aktif_hari} days", shell=True)

    # Simpan ke database
    os.makedirs("/etc/ssh", exist_ok=True)
    subprocess.run(f"sed -i '/\\b{username}\\b/d' /etc/ssh/.ssh.db", shell=True)
    with open("/etc/ssh/.ssh.db", "a") as f:
        f.write(f"#ssh# {username} {password} {quota_gb} {iplimit} {tgl_exp}\n")


    txt1 = f"""✅ <b>Akun SSH Berhasil Dibuat</b>
👤 <b>Username</b>: <code>{username}</code>
🔑 <b>Password</b>: <code>{password}</code>
⚠️ <b>Device  </b>: <code>{iplimit}</code>
⏳ <b>Expired </b>: <code>{aktif_hari} Days ==> {tgl_exp}</code>"""

    txt2 = f"""◇━━━━━━━━━━━━━━━━━◇
 Format SSH OVPN Account
◇━━━━━━━━━━━━━━━━━◇
Username         : {username}
Password         : {password}
Limit IP         : {iplimit}
Limit Kuota      : {quota_gb} GB
IP VPS           : {ipvps}
Domain           : {domain}
Port SSH         : 22, 80, 443
Dropbear         : 109, 143
SSL/TLS          : 443, 400-900
SSH WS           : 80, 8080, 8081-9999
SSH WS SSL       : 443
OVPN WS SSL      : 443
OVPN TCP         : 1194
OVPN UDP         : 2200
BadVPN UDP       : 7100, 7200, 7300
◇━━━━━━━━━━━━━━━━━◇
Aktif Selama     : {aktif_hari} Hari
Dibuat Pada      : {tgl_buat}
Berakhir Pada    : {tgl_exp}
◇━━━━━━━━━━━━━━━━━◇
OVPN Download    : https://{domain}:81/
Save Link        : https://{domain}:81/ssh-{username}.txt"""

    

    await event.respond(txt1, parse_mode="html")
    await asyncio.sleep(3)
    await event.respond(f"<code>{txt2}</code>", parse_mode="html")

#SHOW ALL ACCOUNT
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh_accounts(event):
    from datetime import datetime
    import subprocess

    try:
        result = ""
        with open("/etc/passwd", "r") as f:
            for line in f:
                user = line.split(":")[0]
                uid = int(line.split(":")[2])
                if uid >= 1000 and user != "nobody":
                    try:
                        exp_raw = subprocess.getoutput(f"chage -l {user} | grep 'Account expires' | awk -F': ' '{{print $2}}'")
                        if "never" in exp_raw:
                            sisa = "∞"
                        else:
                            exp_date = datetime.strptime(exp_raw, "%b %d, %Y")
                            today = datetime.today()
                            sisa = (exp_date - today).days
                        result += f"👤 <b>{user}</b>\n📅 Exp: <code>{exp_raw}</code> ⏳ Sisa: <code>{sisa} hari</code>\n\n"
                    except:
                        continue

        await event.edit(
            result or "❌ Tidak ada akun ditemukan.",
            parse_mode='html',
            buttons=[[Button.inline("🔙 Kembali", b"ssh")]]
        )
    except Exception as e:
        await event.edit(
            f"Terjadi kesalahan:\n<code>{e}</code>",
            parse_mode='html',
            buttons=[[Button.inline("🔙 Kembali", b"ssh")]]
        )


#DELETE SSH
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def show_ssh_accounts(event):
    from datetime import datetime
    import subprocess

    try:
        rows = []
        with open("/etc/passwd", "r") as f:
            for line in f:
                user = line.split(":")[0]
                uid = int(line.split(":")[2])
                if uid >= 1000 and user != "nobody":
                    try:
                        exp_raw = subprocess.getoutput(
                            f"chage -l {user} | grep 'Account expires' | awk -F': ' '{{print $2}}'"
                        )
                        if "never" in exp_raw:
                            sisa = "∞"
                        else:
                            exp_date = datetime.strptime(exp_raw, "%b %d, %Y")
                            today = datetime.today()
                            sisa = (exp_date - today).days
                        user_info = f"👤 <b>{user}</b>\n📅 Exp: <code>{exp_raw}</code> ⏳ Sisa: <code>{sisa} hari</code>"
                        rows.append((user_info, user))
                    except:
                        continue

        if not rows:
            await event.edit("❌ Tidak ada akun SSH ditemukan.", buttons=[[Button.inline("🔙 Kembali", b"ssh")]])
            return

        # Kirim satu per satu agar bisa diklik untuk delete
        for user_text, user in rows:
            await event.respond(
                user_text,
                parse_mode="html",
                buttons=[[Button.inline(f"🗑️ Hapus {user}", f"deluser:{user}")]]
            )

        await event.respond("⬆️ Daftar akun ditampilkan.\n🔙 Tekan tombol di bawah untuk kembali.",
                            buttons=[[Button.inline("🔙 Kembali", b"ssh")]])

    except Exception as e:
        await event.respond(f"❌ Terjadi kesalahan:\n<code>{e}</code>", parse_mode='html')

# Penjadwalan notifikasi H-3 sebelum expired
h3_date = now + DT.timedelta(days=int(aktif_hari) - 3)
h3_cmd = (
    f"echo 'python3 /root/kyt/kyt/modules/ssh.py --notif {sender.id} {username} {tgl_exp}' "
    f"| at {h3_date.strftime('%H:%M %Y-%m-%d')}"
)
subprocess.run(h3_cmd, shell=True)

#HANDLER DELETE
@bot.on(events.CallbackQuery(pattern=b'deluser:(.+)'))
async def delete_user_handler(event):
    import subprocess
    user = event.data.decode().split(":")[1]

    try:
        subprocess.run(["userdel", "-r", user], check=True)
        await event.respond(f"✅ User <code>{user}</code> berhasil dihapus.", parse_mode="html")
    except subprocess.CalledProcessError:
        await event.respond(f"❌ Gagal menghapus user <code>{user}</code>. Mungkin sedang login.", parse_mode="html")


#CHECK LOGIN
import os
import subprocess
from telethon import events, Button

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def check_full_ssh_logins(event):
    sender = await event.get_sender()

    if valid(str(sender.id)) != "true":
        await event.answer("Akses ditolak", alert=True)
        return

    msg = "📡 <b>Daftar Login SSH/OpenVPN Aktif</b>\n\n"

    # Log file
    LOG = "/var/log/auth.log"
    if not os.path.exists(LOG):
        LOG = "/var/log/secure"

        # DROPBEAR login
    try:
        msg += "<b>🔐 DROPBEAR:</b>\n"
        dropbear_pids = subprocess.getoutput("ps aux | grep -i dropbear | awk '{print $2}'").splitlines()
        dropbear_logins = subprocess.getoutput(f"grep -i 'Password auth succeeded' {LOG} | grep -i dropbear").splitlines()

        count = 0
        for pid in dropbear_pids:
            for line in dropbear_logins:
                if f"dropbear[{pid}]" in line:
                    # Contoh log format:
                    # dropbear[1234]: Password auth succeeded for 'username' from 123.123.123.123:port
                    match = re.search(r"Password auth succeeded for '(.+)' from ([\d\.]+)", line)
                    if match:
                        user = match.group(1)
                        ip = match.group(2)
                        msg += f"👤 <code>{user}</code> 🌍 <code>{ip}</code>\n"
                        count += 1
        if count == 0:
            msg += "❌ Tidak ada login aktif.\n"
    except Exception as e:
        msg += f"⚠️ Gagal ambil dropbear login: {e}\n"
    # SSHD login
    msg += "\n<b>🔑 SSHD:</b>\n"
    try:
        sshd_logins = subprocess.getoutput(f"grep 'Accepted password for' {LOG} | grep sshd").splitlines()
        sshd_pids = subprocess.getoutput("ps aux | grep '\\[priv\\]' | awk '{{print $2}}'").splitlines()

        count = 0
        for pid in sshd_pids:
            for line in sshd_logins:
                if f"sshd[{pid}]" in line:
                    # Contoh log:
                    # sshd[2345]: Accepted password for username from 111.222.111.222 port 54321
                    match = re.search(r"Accepted password for (\w+) from ([\d\.]+)", line)
                    if match:
                        user = match.group(1)
                        ip = match.group(2)
                        msg += f"👤 <code>{user}</code> 🌍 <code>{ip}</code>\n"
                        count += 1
        if count == 0:
            msg += "❌ Tidak ada login aktif.\n"
    except Exception as e:
        msg += f"⚠️ Gagal ambil sshd login: {e}\n"

    # OpenVPN TCP
    msg += "\n<b>🌐 OpenVPN TCP:</b>\n"
    tcp_log = "/etc/openvpn/server/openvpn-tcp.log"
    if os.path.exists(tcp_log):
        try:
            tcp_data = subprocess.getoutput(f"grep '^CLIENT_LIST' {tcp_log} | cut -d ',' -f 2,3,8").splitlines()
            if tcp_data:
                for line in tcp_data:
                    user, ip, time = line.strip().split()
                    msg += f"👤 <code>{user}</code> 🌍 <code>{ip}</code> ⏱️ <code>{time}</code>\n"
            else:
                msg += "❌ Tidak ada koneksi TCP.\n"
        except Exception as e:
            msg += f"⚠️ Error: {e}\n"
    else:
        msg += "⚠️ Log tidak ditemukan.\n"

    # OpenVPN UDP
    msg += "\n<b>🌐 OpenVPN UDP:</b>\n"
    udp_log = "/etc/openvpn/server/openvpn-udp.log"
    if os.path.exists(udp_log):
        try:
            udp_data = subprocess.getoutput(f"grep '^CLIENT_LIST' {udp_log} | cut -d ',' -f 2,3,8").splitlines()
            if udp_data:
                for line in udp_data:
                    user, ip, time = line.strip().split()
                    msg += f"👤 <code>{user}</code> 🌍 <code>{ip}</code> ⏱️ <code>{time}</code>\n"
            else:
                msg += "❌ Tidak ada koneksi UDP.\n"
        except Exception as e:
            msg += f"⚠️ Error: {e}\n"
    else:
        msg += "⚠️ Log tidak ditemukan.\n"

    await event.edit(msg, parse_mode="html", buttons=[[Button.inline("🔙 Kembali", b"ssh")]])

#NOTIF
async def notif_expired_ssh(user_id, username, tgl_exp):
    message = f"⚠️ <b>Peringatan!</b>\nAkun SSH <code>{username}</code> akan <b>expired</b> pada <b>{tgl_exp}</b> (3 hari lagi)."
    try:
        await bot.send_message(int(user_id), message, parse_mode="html")
    except Exception as e:
        print(f"Gagal kirim notifikasi ke {user_id}: {e}")
if __name__ == "__main__":
    import sys
    if len(sys.argv) == 4 and sys.argv[1] == "--notif":
        # Contoh: python3 ssh.py --notif 123456789 user123 10-Sep-2025
        user_id = sys.argv[2]
        username = sys.argv[3]
        tgl_exp = sys.argv[4]

        # Jalankan notifikasi lewat event loop
        import asyncio
        asyncio.run(notif_expired_ssh(user_id, username, tgl_exp))
