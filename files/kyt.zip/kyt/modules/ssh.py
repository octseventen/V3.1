from kyt import *
import asyncio
import subprocess
import time
import random
import datetime as DT
import os
import re
import requests
from telethon import events, Button

#MENU TRIAL
@bot.on(events.CallbackQuery(data=b"trial-ssh"))
async def trial_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond("🕐 Masukkan Durasi Trial (menit):")
        menit = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

    try:
        menit_int = int(menit)
        if menit_int <= 0 or menit_int > 1440:
            raise ValueError
    except:
        await event.respond("❌ Durasi harus angka (1–1440 menit).")
        return

    # Auto generate username & password
    rand_suffix = random.randint(1000, 9999)
    username = f"Trial-{rand_suffix}"
    password = "1"

    # Tanggal & expired
    now = DT.datetime.now()
    expired_time = now + DT.timedelta(minutes=menit_int)
    tgl_exp = expired_time.strftime("%H:%M:%S %d-%b-%Y")

    # Ambil domain & IP
    try:
        domain = open("/etc/xray/domain").read().strip()
        ipvps = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    except:
        domain = "unknown"
        ipvps = "0.0.0.0"

    try:
        subprocess.run(f"useradd -e {expired_time.strftime('%Y-%m-%d')} -s /bin/false -M {username}", shell=True, check=True)
        subprocess.run(f"echo '{username}:{password}' | chpasswd", shell=True, check=True)
    except Exception as e:
        await event.respond(f"❌ Gagal membuat akun `{username}`.\nError: {e}")
        return

    # Auto delete by at
    subprocess.run(f"echo 'userdel -f {username}' | at now + {menit_int} minutes", shell=True)

    # Simpan ke log database trial (opsional)
    with open("/etc/ssh/.ssh.db", "a") as f:
        f.write(f"#trial# {username} {password} {tgl_exp}\n")

    # Kirim laporan
    msg = f"""◇━━━━━━━━━━━━━━━━◇
 Trial SSH Account
◇━━━━━━━━━━━━━━━━◇
Username   : {username}
Password   : {password}
IP VPS     : {ipvps}
Domain     : {domain}
Ports      : 22, 80, 443, 109, 143, 1194, 2200
Aktif s/d  : {tgl_exp}
Durasi     : {menit_int} menit
◇━━━━━━━━━━━━━━━━◇"""

    await event.respond(f"<code>{msg}</code>", parse_mode="html")

#CREATE SSH
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond("🧾 Masukkan Username:")
        username = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        # Validasi username
        if not re.match("^[a-zA-Z][a-zA-Z0-9_-]{2,15}$", username):
            await event.respond("❌ Username tidak valid. Harus diawali huruf, 3–16 karakter, hanya a-z, 0-9, -, _")
            return

        # Cek user sudah ada
        if subprocess.run(f"id -u {username}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
            await event.respond(f"❌ Username `{username}` sudah terdaftar.")
            return

        await conv.send_message("🔐 Masukkan Password:")
        password = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("🌐 Limit IP Login:")
        iplimit = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("💾 Limit Kuota (GB):")
        quota_gb = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("⏳ Masa aktif (hari):")
        aktif_hari = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

    await event.respond("⏳ Membuat akun, harap tunggu...")

    # Ambil domain dan IP
    try:
        with open("/etc/xray/domain", "r") as f:
            domain = f.read().strip()
        ipvps = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode().strip()
    except:
        domain = "unknown"
        ipvps = "0.0.0.0"

    now = DT.datetime.now()
    tgl_buat = now.strftime("%d %b %Y")
    tgl_exp = (now + DT.timedelta(days=int(aktif_hari))).strftime("%d %b %Y")
    expired_date = (now + DT.timedelta(days=int(aktif_hari))).strftime("%Y-%m-%d")

    # Buat user
    try:
        subprocess.run(f"useradd -e {expired_date} -s /bin/false -M {username}", shell=True, check=True)
    except subprocess.CalledProcessError as e:
        await event.respond(f"❌ Gagal membuat akun `{username}`.\nError: {e}")
        return

    # Set password pakai chpasswd
    try:
        subprocess.run(f"echo '{username}:{password}' | chpasswd", shell=True, check=True)
    except subprocess.CalledProcessError as e:
        subprocess.run(f"userdel -f {username}", shell=True)
        await event.respond(f"❌ Gagal mengatur password. Akun `{username}` dibatalkan.\nError: {e}")
        return

    # Simpan IP limit
    os.makedirs("/etc/kyt/limit/ssh/ip", exist_ok=True)
    if iplimit.isdigit() and int(iplimit) > 0:
        with open(f"/etc/kyt/limit/ssh/ip/{username}", "w") as f:
            f.write(iplimit)

    # Simpan quota
    try:
        quota_byte = int(quota_gb) * 1024 * 1024 * 1024
    except:
        quota_byte = 0

    if quota_byte > 0:
        os.makedirs("/etc/ssh", exist_ok=True)
        with open(f"/etc/ssh/{username}", "w") as f:
            f.write(str(quota_byte))

    # Auto delete
    subprocess.run(f"echo 'userdel -f {username}' | at now + {aktif_hari} days", shell=True)

    # Simpan ke database
    os.makedirs("/etc/ssh", exist_ok=True)
    subprocess.run(f"sed -i '/\\b{username}\\b/d' /etc/ssh/.ssh.db", shell=True)
    with open("/etc/ssh/.ssh.db", "a") as f:
        f.write(f"#ssh# {username} {password} {quota_gb} {iplimit} {tgl_exp}\n")


    txt1 = f"""✅ <b>Akun SSH Berhasil Dibuat</b>
👤 <b>Username</b>: <code>{username}</code>
🔑 <b>Password</b>: <code>{password}</code>
⚠️ <b>Device  </b>: <code>{iplimit}</code>
⏳ <b>Expired </b>: <code>{aktif_hari} Days ==> {tgl_exp}</code>"""

    txt2 = f"""◇━━━━━━━━━━━━━━━━━◇
 Format SSH OVPN Account
◇━━━━━━━━━━━━━━━━━◇
Username         : {username}
Password         : {password}
Limit IP         : {iplimit}
Limit Kuota      : {quota_gb} GB
IP VPS           : {ipvps}
Domain           : {domain}
Port SSH         : 22, 80, 443
Dropbear         : 109, 143
SSL/TLS          : 443, 400-900
SSH WS           : 80, 8080, 8081-9999
SSH WS SSL       : 443
OVPN WS SSL      : 443
OVPN TCP         : 1194
OVPN UDP         : 2200
BadVPN UDP       : 7100, 7200, 7300
◇━━━━━━━━━━━━━━━━━◇
Aktif Selama     : {aktif_hari} Hari
Dibuat Pada      : {tgl_buat}
Berakhir Pada    : {tgl_exp}
◇━━━━━━━━━━━━━━━━━◇
OVPN Download    : https://{domain}:81/
Save Link        : https://{domain}:81/ssh-{username}.txt"""

    

    await event.respond(txt1, parse_mode="html")
    await asyncio.sleep(3)
    await event.respond(f"<code>{txt2}</code>", parse_mode="html")

#SHOW ALL ACCOUNT
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh_accounts(event):
    from datetime import datetime
    import subprocess

    try:
        result = ""
        with open("/etc/passwd", "r") as f:
            for line in f:
                user = line.split(":")[0]
                uid = int(line.split(":")[2])
                if uid >= 1000 and user != "nobody":
                    # Ambil expired date
                    try:
                        exp_raw = subprocess.getoutput(f"chage -l {user} | grep 'Account expires' | awk -F': ' '{{print $2}}'")
                        if "never" in exp_raw:
                            sisa = "∞"
                        else:
                            exp_date = datetime.strptime(exp_raw, "%b %d, %Y")
                            today = datetime.today()
                            sisa = (exp_date - today).days
                        result += f"👤 <b>{user}</b>\n📅 Exp: <code>{exp_raw}</code> ⏳ Sisa: <code>{sisa} hari</code>\n\n"
                    except:
                        continue

        await event.respond(result or "❌ Tidak ada akun ditemukan.", parse_mode='html')
    except Exception as e:
        await event.respond(f"Terjadi kesalahan:\n<code>{e}</code>", parse_mode='html')

#CHECK LOGIN
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def check_ssh_logins(event):
    try:
        # Ambil semua login aktif
        login_info = subprocess.check_output("who", shell=True).decode().strip()

        if not login_info:
            await event.respond("👤 Tidak ada user SSH yang sedang login.")
            return

        msg = "📡 <b>Daftar User SSH Login Aktif</b>\n\n"
        login_lines = login_info.splitlines()

        # Tambahkan ke pesan
        for line in login_lines:
            parts = line.split()
            if len(parts) >= 5:
                username = parts[0]
                ipaddr = parts[-1]
                waktu = " ".join(parts[2:4])
                msg += f"👤 <b>User:</b> <code>{username}</code>\n"
                msg += f"⏱️ <b>Login:</b> <code>{waktu}</code>\n"
                msg += f"🌐 <b>IP:</b> <code>{ipaddr}</code>\n"
                msg += "━━━━━━━━━━━━━━\n"

        msg += "\n🔙 Tekan tombol di bawah untuk kembali."
        await event.respond(msg, parse_mode="html", buttons=[[Button.inline("🔙 Kembali", b"back-to-menu")]])

    except Exception as e:
        await event.respond(f"❌ Gagal mengambil data login.\n<code>{e}</code>", parse_mode="html")

#DELETE SSH
from kyt import *
import asyncio
import subprocess
import time
import random
import datetime as DT
import os
import re
import requests
import pwd
from telethon import events, Button

# Fungsi validasi user (anggap sudah ada)
def valid(user_id):
    # Contoh validasi sederhana (ubah sesuai kebutuhan)
    allowed = ["123456789", "987654321"]  # contoh id user yang diizinkan
    return "true" if user_id in allowed else "false"

#==========================
#== MENU UTAMA ============
#==========================
async def show_main_menu(chat_id):
    buttons = [
        [Button.inline("Trial SSH", b"trial-ssh")],
        [Button.inline("Buat Akun SSH", b"create-ssh")],
        [Button.inline("Hapus Akun SSH", b"delete-ssh")],
    ]
    await bot.send_message(chat_id, "📂 <b>Menu SSH Manager</b>", buttons=buttons, parse_mode="html")


@bot.on(events.NewMessage(pattern="/start"))
async def start_handler(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.respond("Akses Ditolak")
        return

    await show_main_menu(chat)

#==========================
#== TRIAL SSH =============
#==========================
@bot.on(events.CallbackQuery(data=b"trial-ssh"))
async def trial_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.edit("🕐 Masukkan Durasi Trial (menit):", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
        menit_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        menit = menit_msg.raw_text.strip()

    if not menit.isdigit() or int(menit) <= 0 or int(menit) > 1440:
        await event.respond("❌ Durasi harus angka antara 1–1440 menit.", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
        return

    menit_int = int(menit)
    rand_suffix = random.randint(1000, 9999)
    username = f"Trial-{rand_suffix}"
    password = "1"

    now = DT.datetime.now()
    expired_time = now + DT.timedelta(minutes=menit_int)
    tgl_exp = expired_time.strftime("%H:%M:%S %d-%b-%Y")

    try:
        domain = open("/etc/xray/domain").read().strip()
        ipvps = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    except:
        domain = "unknown"
        ipvps = "0.0.0.0"

    try:
        subprocess.run(f"useradd -e {expired_time.strftime('%Y-%m-%d')} -s /bin/false -M {username}", shell=True, check=True)
        subprocess.run(f"echo '{username}:{password}' | chpasswd", shell=True, check=True)
    except Exception as e:
        await event.respond(f"❌ Gagal membuat akun `{username}`.\nError: {e}", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
        return

    subprocess.run(f"echo 'userdel -f {username}' | at now + {menit_int} minutes", shell=True)
    with open("/etc/ssh/.ssh.db", "a") as f:
        f.write(f"#trial# {username} {password} {tgl_exp}\n")

    msg = f"""◇━━━━━━━━━━━━━━━━◇
 Trial SSH Account
◇━━━━━━━━━━━━━━━━◇
Username   : {username}
Password   : {password}
IP VPS     : {ipvps}
Domain     : {domain}
Ports      : 22, 80, 443, 109, 143, 1194, 2200
Aktif s/d  : {tgl_exp}
Durasi     : {menit_int} menit
◇━━━━━━━━━━━━━━━━◇"""

    await event.edit(f"<code>{msg}</code>", parse_mode="html", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])


#==========================
#== CREATE SSH ============
#==========================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.edit("🧾 Masukkan Username:", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
        username_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        username = username_msg.raw_text.strip()

        if not re.match("^[a-zA-Z][a-zA-Z0-9_-]{2,15}$", username):
            await event.respond("❌ Username tidak valid.", buttons=[
                [Button.inline("Kembali", b"back-to-main")]
            ])
            return

        if subprocess.run(f"id -u {username}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
            await event.respond(f"❌ Username `{username}` sudah ada.", buttons=[
                [Button.inline("Kembali", b"back-to-main")]
            ])
            return

        await conv.send_message("🔐 Masukkan Password:")
        password_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        password = password_msg.raw_text.strip()

        await conv.send_message("🌐 Limit IP Login:")
        iplimit_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        iplimit = iplimit_msg.raw_text.strip()

        await conv.send_message("💾 Limit Kuota (GB):")
        quota_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        quota_gb = quota_msg.raw_text.strip()

        await conv.send_message("⏳ Masa aktif (hari):")
        aktif_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        aktif_hari = aktif_msg.raw_text.strip()

    await event.respond("⏳ Membuat akun...", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])

    try:
        domain = open("/etc/xray/domain").read().strip()
        ipvps = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    except:
        domain = "unknown"
        ipvps = "0.0.0.0"

    now = DT.datetime.now()
    tgl_buat = now.strftime("%d %b %Y")
    tgl_exp = (now + DT.timedelta(days=int(aktif_hari))).strftime("%d %b %Y")
    expired_date = (now + DT.timedelta(days=int(aktif_hari))).strftime("%Y-%m-%d")

    subprocess.run(f"useradd -e {expired_date} -s /bin/false -M {username}", shell=True, check=True)
    subprocess.run(f"echo '{username}:{password}' | chpasswd", shell=True, check=True)

    os.makedirs("/etc/kyt/limit/ssh/ip", exist_ok=True)
    if iplimit.isdigit():
        with open(f"/etc/kyt/limit/ssh/ip/{username}", "w") as f:
            f.write(iplimit)

    try:
        quota_byte = int(quota_gb) * 1024**3
        with open(f"/etc/ssh/{username}", "w") as f:
            f.write(str(quota_byte))
    except:
        pass

    subprocess.run(f"echo 'userdel -f {username}' | at now + {aktif_hari} days", shell=True)
    subprocess.run(f"sed -i '/\\b{username}\\b/d' /etc/ssh/.ssh.db", shell=True)
    with open("/etc/ssh/.ssh.db", "a") as f:
        f.write(f"#ssh# {username} {password} {quota_gb} {iplimit} {tgl_exp}\n")

    txt1 = f"""✅ <b>Akun SSH Berhasil Dibuat</b>
👤 <b>Username</b>: <code>{username}</code>
🔑 <b>Password</b>: <code>{password}</code>
⚠️ <b>Device</b>: <code>{iplimit}</code>
⏳ <b>Expired</b>: <code>{aktif_hari} Days ==> {tgl_exp}</code>"""

    txt2 = f"""◇━━━━━━━━━━━━━━━━━◇
 Format SSH OVPN Account
◇━━━━━━━━━━━━━━━━━◇
Username         : {username}
Password         : {password}
Limit IP         : {iplimit}
Limit Kuota      : {quota_gb} GB
IP VPS           : {ipvps}
Domain           : {domain}
◇━━━━━━━━━━━━━━━━━◇
Aktif Selama     : {aktif_hari} Hari
Dibuat Pada      : {tgl_buat}
Berakhir Pada    : {tgl_exp}
◇━━━━━━━━━━━━━━━━━◇
OVPN Download    : https://{domain}:81/
Save Link        : https://{domain}:81/ssh-{username}.txt"""

    await event.respond(txt1, parse_mode="html", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])
    await asyncio.sleep(2)
    await event.respond(f"<code>{txt2}</code>", parse_mode="html", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])


#==========================
#== DELETE SSH ============
#==========================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh_menu(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    users = [u.pw_name for u in pwd.getpwall() if u.pw_uid >= 1000 and "home" in u.pw_dir]
    if not users:
        await event.edit("❌ Tidak ada akun SSH untuk dihapus.", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
        return

    user_list = "\n".join([f"- <code>{u}</code>" for u in users])
    await event.edit(f"📜 <b>Daftar Akun:</b>\n\n{user_list}\n\n🗑️ <b>Ketik username</b> yang ingin dihapus:", parse_mode="html", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])

    @bot.on(events.NewMessage(from_users=sender.id))
    async def process_delete(ev):
        username = ev.raw_text.strip()
        if username not in users:
            await ev.respond(f"❌ Username <code>{username}</code> tidak ditemukan.", parse_mode="html", buttons=[
                [Button.inline("Kembali", b"back-to-main")]
            ])
        else:
            await ev.respond(
                f"⚠️ Yakin ingin menghapus akun <code>{username}</code>?",
                parse_mode="html",
                buttons=[
                    [Button.inline("✅ Ya, hapus", data=f"confirm-delete-{username}"), Button.inline("❌ Batal", data="cancel-delete")]
                ],
            )
        bot.remove_event_handler(process_delete)

@bot.on(events.CallbackQuery(pattern=b"confirm-delete-(.+)"))
async def confirm_delete(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    username = event.data.decode().split(b"-")[-1].decode()

    try:
        subprocess.run(f"userdel -r {username}", shell=True, check=True)
        subprocess.run(f"sed -i '/\\b{username}\\b/d' /etc/ssh/.ssh.db", shell=True)
        await event.edit(f"✅ Akun <code>{username}</code> berhasil dihapus.", parse_mode="html", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
    except Exception as e:
        await event.edit(f"❌ Gagal menghapus akun <code>{username}</code>.\nError: {e}", parse_mode="html", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])

@bot.on(events.CallbackQuery(data=b"cancel-delete"))
async def cancel_delete(event):
    await event.edit("❌ Penghapusan akun dibatalkan.", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])


#==========================
#== BUTTON BACK TO MAIN ===
#==========================
@bot.on(events.CallbackQuery(data=b"back-to-main"))
async def back_to_main(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
    await event.edit("📂 Kembali ke Menu Utama", buttons=None)
    await show_main_menu(event.chat_id)



#MENU SSH
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh_menu(event):
    sender = await event.get_sender()

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    try:
        with open("/etc/xray/domain", "r") as f:
            domain = f.read().strip()
    except:
        domain = "domain.tidak.terdeteksi"
    msg = f"""
◇━━━━━━━━━━━━━━━━━━━━━━◇
   🇮🇩 <b>SSH/OPENVPN MENU</b> 🇮🇩
◇━━━━━━━━━━━━━━━━━━━━━━◇
🔰 <b>Service</b>: SSH & OVPN
🌐 <b>Hostname/IP</b>: <code>{domain}</code>
🏢 <b>ISP</b>: {z['isp']}
🌍 <b>Country</b>: {z['country']}
◇━━━━━━━━━━━━━━━━━━━━━━◇
"""

    tombol = [
        [Button.inline("⚡ TRIAL SSH", b"trial-ssh"), Button.inline("➕ CREATE SSH", b"create-ssh")],
        [Button.inline("❌ DELETE SSH", b"delete-ssh"), Button.inline("👀 CHECK LOGIN", b"login-ssh")],
        [Button.inline("📋 SHOW USER", b"show-ssh")],
        [Button.inline("🔙 Main Menu", b"menu")]
    ]

    await event.edit(msg, buttons=tombol, parse_mode="html")
