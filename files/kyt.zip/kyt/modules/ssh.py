from kyt import *
import asyncio
import subprocess
import time
import random
import datetime as DT
import requests
from telethon import events, Button

# DELETE SSH
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond("**Username To Be Deleted:**")
        response = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        username = response.raw_text

    cmd = f'printf "%s\n" "{username}" | delssh'
    try:
        subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"**Successfully Deleted** `{username}`")
    except subprocess.CalledProcessError:
        await event.respond(f"**User** `{username}` **Not Found**")

# CREATE SSH
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond('**Username:**')
        username = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message('**Password:**')
        password = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message('**Limit IP:**')
        iplimit = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message('**Expiry Time (in days):**')
        exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

    # Progress UI
    for msg in ["Processing.", "Processing..", "Processing..."]:
        await event.edit(msg)
        time.sleep(1)

    await event.edit("`Wait.. Setting up an Account`")
    for step in ["0%", "8%", "20%", "52%", "84%", "100%"]:
        filled = '█' * (int(step[:-1]) // 4)
        empty = '▒' * (25 - len(filled))
        await event.edit(f"`Processing... {step}\n{filled}{empty}`")
        time.sleep(1)

    # Hitung tanggal expired
    expired_date = (DT.date.today() + DT.timedelta(days=int(exp))).strftime('%Y-%m-%d')

    # Buat perintah: useradd, password, simpan limitip
    try:
    
    cmd = f'''
useradd -e {expired_date} -s /bin/false -M {username} && \
echo -e "{password}\\n{password}" | passwd {username} &>/dev/null && \
mkdir -p /etc/kyt/limit/ssh/ip && \
echo "{iplimit}" > /etc/kyt/limit/ssh/ip/{username}
    ''' 
    subprocess.run(cmd, shell=True, executable="/bin/bash", check=True)
    except subprocess.CalledProcessError:
        await event.respond("❌ **Gagal membuat akun. Username mungkin sudah ada.**")
        return      

    # Kirim hasil ke Telegram
    expired_display = (DT.date.today() + DT.timedelta(days=int(exp))).strftime('%d %b %Y')
    


#PESAN KE TELE UNTUK VIP AKUN
    msg = f"""
**━━━━━━━━━━━━━━━━━**
**🇮🇩🇮🇩 SSH OVPN VIP ACCOUNT 🇮🇩🇮🇩**
**━━━━━━━━━━━━━━━━━**
👤 **Username: ** `{username}`
🔑 **Password: ** `{password}`
🌐 **Host: ** `{DOMAIN}`
**━━━━━━━━━━━━━━━━━━**
🔌 **List Ports:**
• OpenSSH: 443, 80, 22
• DNS: 443, 53, 22
• Dropbear: 443, 109
• Dropbear WS: 443, 109
• SSH WS: 80, 8080, 8081-9999
• SSH SSL WS: 443
• SSL/TLS: 222-1000
• OVPN WS SSL: 443
• OVPN SSL: 443
• OVPN TCP: 443, 1194
• OVPN UDP: 2200
• Squid Proxy: 3128
• BadVPN UDP: 7100, 7300, 7300
**━━━━━━━━━━━━━━━━━━**
📡 **Payload WSS:**
`GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━━**
📥 **OVPN Downloads:**
• WS SSL: https://{DOMAIN}:81/ws-ssl.ovpn
• SSL: https://{DOMAIN}:81/ssl.ovpn
• TCP: https://{DOMAIN}:81/tcp.ovpn
• UDP: https://{DOMAIN}:81/udp.ovpn
**━━━━━━━━━━━━━━━━━━**
💾 **Save Link:** https://{DOMAIN}:81/ssh-{username_clean}.txt
⏳ **Expired:** {expired_date}
"""

    msg2 = f"""
**━━━━━━━━━━━━━━━━━━**
**✅ SSH VIP ACCOUNT ✅**
**━━━━━━━━━━━━━━━━━━**
👤 **Username: ** `{username}`
🔑 **Password: ** `{password}`
🌐 **Host: ** `{DOMAIN}`
🔌 **Device: ** `{iplimit}`
⏳ **Expired: ** `{exp}` Days =>> `{expired_date}`
**━━━━━━━━━━━━━━━━━━**
"""

    await event.respond(msg)
    await asyncio.sleep(3)
    await event.respond(msg2)
    
    
#CHECK LOGIN
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    try:
        cmd = 'bot-cek-login-ssh'
        result = subprocess.check_output(cmd, shell=True).decode()
        await event.respond(f"<b>🟢 SSH Online:</b>\n<pre>{result}</pre>", parse_mode='html')
    except:
        await event.respond("❌ Gagal membaca login SSH.")

#LIST AKUN
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    try:
        cmd = 'bot-member-ssh'
        result = subprocess.check_output(cmd, shell=True).decode()
        await event.respond(f"<b>📋 SSH User List:</b>\n<pre>{result}</pre>", parse_mode='html')
    except:
        await event.respond("❌ Gagal membaca daftar akun SSH.")

#TRAIL AKUN
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    chat = event.chat_id
    async with bot.conversation(chat) as conv:
        await event.respond("⏳ <b>Masukkan masa aktif trial (menit):</b>", parse_mode='html')
        pup = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

    await event.edit("`Sedang membuat akun trial...`")

    try:
        # Panggil skrip trialssh dengan parameter menit
        cmd = f'echo "{pup}" | trial'
        output = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()

        # Karena hasil dikirim ke Telegram dari dalam skrip Bash,
        # cukup beri notifikasi berhasil di bot:
        await event.respond("✅ Akun trial berhasil dibuat dan dikirim ke Telegram.")
    except subprocess.CalledProcessError as e:
        await event.respond(f"❌ Gagal membuat akun trial.\n<code>{e.output.decode()}</code>", parse_mode='html')




        msg = f"""
<b>✅ TRIAL SSH ACCOUNT</b>
━━━━━━━━━━━━━━━━━━
👤 <b>Username:</b> <code>{username}</code>
🔑 <b>Password:</b> <code>{password}</code>
🌐 <b>Host/IP:</b> <code>{ip}</code>
📡 <b>Domain:</b> <code>{domain}</code>
⏳ <b>Expired:</b> {pup} menit
━━━━━━━━━━━━━━━━━━
<b>Ports:</b>
• OpenSSH: 22
• Dropbear: 443, 109
• SSL/TLS: 400-900
• SSH WS SSL: 443
• SSH WS NTLS: 80, 8080, 8081-9999
• OVPN WS SSL: 443
• OVPN WS NTLS: 80, 8080, 8880
• BadVPN UDP: 7100,7200,7300
━━━━━━━━━━━━━━━━━━
🔗 <b>OVPN Download:</b> https://{domain}:81/
📄 <b>Save Link:</b> https://{domain}:81/ssh-{username}.txt
"""
        await event.respond(msg, parse_mode='html')
    except Exception as e:
        await event.respond(f"Gagal membuat akun trial.\n<b>Error:</b> <code>{e}</code>", parse_mode='html')



# SSH MENU
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    inline = [
        [Button.inline("TRIAL SSH", b'trial-ssh'), Button.inline("CREATE SSH", b'create-ssh')],
        [Button.inline("DELETE SSH", b'delete-ssh'), Button.inline("CHECK Login SSH", b'login-ssh')],
        [Button.inline("SHOW All USER SSH", b'show-ssh'), Button.inline("‹ Main Menu ›", b'menu')]
    ]

    z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━** 
**🇮🇩 LORDFREEDOM 🇮🇩**
**━━━━━━━━━━━━━━━━━━━━━━━** 
**🇮🇩 SSH/OPENVPN**
**━━━━━━━━━━━━━━━━━━━━━━━** 
🔰 **Service:** `SSH OVPN`
🔰 **Hostname/IP:** `{DOMAIN}`
🔰 **ISP:** `{z['isp']}`
🔰 **Country:** `{z['country']}`
**━━━━━━━━━━━━━━━━━━━━━━━** 
"""
    await event.edit(msg, buttons=inline)
