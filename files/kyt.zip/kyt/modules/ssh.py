from kyt import *
import asyncio
import subprocess
import time
import random
import datetime as DT
import os
import re
import requests
import pwd
from telethon import events, Button

# Fungsi validasi user (anggap sudah ada)
def valid(user_id):
    # Contoh validasi sederhana (ubah sesuai kebutuhan)
    allowed = ["123456789", "987654321"]  # contoh id user yang diizinkan
    return "true" if user_id in allowed else "false"

#==========================
#== MENU UTAMA ============
#==========================
async def show_main_menu(chat_id):
    buttons = [
        [Button.inline("Trial SSH", b"trial-ssh")],
        [Button.inline("Buat Akun SSH", b"create-ssh")],
        [Button.inline("Hapus Akun SSH", b"delete-ssh")],
    ]
    await bot.send_message(chat_id, "📂 <b>Menu SSH Manager</b>", buttons=buttons, parse_mode="html")


@bot.on(events.NewMessage(pattern="/start"))
async def start_handler(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.respond("Akses Ditolak")
        return

    await show_main_menu(chat)

#==========================
#== TRIAL SSH =============
#==========================
@bot.on(events.CallbackQuery(data=b"trial-ssh"))
async def trial_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.edit("🕐 Masukkan Durasi Trial (menit):", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
        menit_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        menit = menit_msg.raw_text.strip()

    if not menit.isdigit() or int(menit) <= 0 or int(menit) > 1440:
        await event.respond("❌ Durasi harus angka antara 1–1440 menit.", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
        return

    menit_int = int(menit)
    rand_suffix = random.randint(1000, 9999)
    username = f"Trial-{rand_suffix}"
    password = "1"

    now = DT.datetime.now()
    expired_time = now + DT.timedelta(minutes=menit_int)
    tgl_exp = expired_time.strftime("%H:%M:%S %d-%b-%Y")

    try:
        domain = open("/etc/xray/domain").read().strip()
        ipvps = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    except:
        domain = "unknown"
        ipvps = "0.0.0.0"

    try:
        subprocess.run(f"useradd -e {expired_time.strftime('%Y-%m-%d')} -s /bin/false -M {username}", shell=True, check=True)
        subprocess.run(f"echo '{username}:{password}' | chpasswd", shell=True, check=True)
    except Exception as e:
        await event.respond(f"❌ Gagal membuat akun `{username}`.\nError: {e}", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
        return

    subprocess.run(f"echo 'userdel -f {username}' | at now + {menit_int} minutes", shell=True)
    with open("/etc/ssh/.ssh.db", "a") as f:
        f.write(f"#trial# {username} {password} {tgl_exp}\n")

    msg = f"""◇━━━━━━━━━━━━━━━━◇
 Trial SSH Account
◇━━━━━━━━━━━━━━━━◇
Username   : {username}
Password   : {password}
IP VPS     : {ipvps}
Domain     : {domain}
Ports      : 22, 80, 443, 109, 143, 1194, 2200
Aktif s/d  : {tgl_exp}
Durasi     : {menit_int} menit
◇━━━━━━━━━━━━━━━━◇"""

    await event.edit(f"<code>{msg}</code>", parse_mode="html", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])


#==========================
#== CREATE SSH ============
#==========================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.edit("🧾 Masukkan Username:", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
        username_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        username = username_msg.raw_text.strip()

        if not re.match("^[a-zA-Z][a-zA-Z0-9_-]{2,15}$", username):
            await event.respond("❌ Username tidak valid.", buttons=[
                [Button.inline("Kembali", b"back-to-main")]
            ])
            return

        if subprocess.run(f"id -u {username}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
            await event.respond(f"❌ Username `{username}` sudah ada.", buttons=[
                [Button.inline("Kembali", b"back-to-main")]
            ])
            return

        await conv.send_message("🔐 Masukkan Password:")
        password_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        password = password_msg.raw_text.strip()

        await conv.send_message("🌐 Limit IP Login:")
        iplimit_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        iplimit = iplimit_msg.raw_text.strip()

        await conv.send_message("💾 Limit Kuota (GB):")
        quota_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        quota_gb = quota_msg.raw_text.strip()

        await conv.send_message("⏳ Masa aktif (hari):")
        aktif_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        aktif_hari = aktif_msg.raw_text.strip()

    await event.respond("⏳ Membuat akun...", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])

    try:
        domain = open("/etc/xray/domain").read().strip()
        ipvps = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    except:
        domain = "unknown"
        ipvps = "0.0.0.0"

    now = DT.datetime.now()
    tgl_buat = now.strftime("%d %b %Y")
    tgl_exp = (now + DT.timedelta(days=int(aktif_hari))).strftime("%d %b %Y")
    expired_date = (now + DT.timedelta(days=int(aktif_hari))).strftime("%Y-%m-%d")

    subprocess.run(f"useradd -e {expired_date} -s /bin/false -M {username}", shell=True, check=True)
    subprocess.run(f"echo '{username}:{password}' | chpasswd", shell=True, check=True)

    os.makedirs("/etc/kyt/limit/ssh/ip", exist_ok=True)
    if iplimit.isdigit():
        with open(f"/etc/kyt/limit/ssh/ip/{username}", "w") as f:
            f.write(iplimit)

    try:
        quota_byte = int(quota_gb) * 1024**3
        with open(f"/etc/ssh/{username}", "w") as f:
            f.write(str(quota_byte))
    except:
        pass

    subprocess.run(f"echo 'userdel -f {username}' | at now + {aktif_hari} days", shell=True)
    subprocess.run(f"sed -i '/\\b{username}\\b/d' /etc/ssh/.ssh.db", shell=True)
    with open("/etc/ssh/.ssh.db", "a") as f:
        f.write(f"#ssh# {username} {password} {quota_gb} {iplimit} {tgl_exp}\n")

    txt1 = f"""✅ <b>Akun SSH Berhasil Dibuat</b>
👤 <b>Username</b>: <code>{username}</code>
🔑 <b>Password</b>: <code>{password}</code>
⚠️ <b>Device</b>: <code>{iplimit}</code>
⏳ <b>Expired</b>: <code>{aktif_hari} Days ==> {tgl_exp}</code>"""

    txt2 = f"""◇━━━━━━━━━━━━━━━━━◇
 Format SSH OVPN Account
◇━━━━━━━━━━━━━━━━━◇
Username         : {username}
Password         : {password}
Limit IP         : {iplimit}
Limit Kuota      : {quota_gb} GB
IP VPS           : {ipvps}
Domain           : {domain}
◇━━━━━━━━━━━━━━━━━◇
Aktif Selama     : {aktif_hari} Hari
Dibuat Pada      : {tgl_buat}
Berakhir Pada    : {tgl_exp}
◇━━━━━━━━━━━━━━━━━◇
OVPN Download    : https://{domain}:81/
Save Link        : https://{domain}:81/ssh-{username}.txt"""

    await event.respond(txt1, parse_mode="html", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])
    await asyncio.sleep(2)
    await event.respond(f"<code>{txt2}</code>", parse_mode="html", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])


#==========================
#== DELETE SSH ============
#==========================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh_menu(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    users = [u.pw_name for u in pwd.getpwall() if u.pw_uid >= 1000 and "home" in u.pw_dir]
    if not users:
        await event.edit("❌ Tidak ada akun SSH untuk dihapus.", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
        return

    user_list = "\n".join([f"- <code>{u}</code>" for u in users])
    await event.edit(f"📜 <b>Daftar Akun:</b>\n\n{user_list}\n\n🗑️ <b>Ketik username</b> yang ingin dihapus:", parse_mode="html", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])

    @bot.on(events.NewMessage(from_users=sender.id))
    async def process_delete(ev):
        username = ev.raw_text.strip()
        if username not in users:
            await ev.respond(f"❌ Username <code>{username}</code> tidak ditemukan.", parse_mode="html", buttons=[
                [Button.inline("Kembali", b"back-to-main")]
            ])
        else:
            await ev.respond(
                f"⚠️ Yakin ingin menghapus akun <code>{username}</code>?",
                parse_mode="html",
                buttons=[
                    [Button.inline("✅ Ya, hapus", data=f"confirm-delete-{username}"), Button.inline("❌ Batal", data="cancel-delete")]
                ],
            )
        bot.remove_event_handler(process_delete)

@bot.on(events.CallbackQuery(pattern=b"confirm-delete-(.+)"))
async def confirm_delete(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    username = event.data.decode().split(b"-")[-1].decode()

    try:
        subprocess.run(f"userdel -r {username}", shell=True, check=True)
        subprocess.run(f"sed -i '/\\b{username}\\b/d' /etc/ssh/.ssh.db", shell=True)
        await event.edit(f"✅ Akun <code>{username}</code> berhasil dihapus.", parse_mode="html", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])
    except Exception as e:
        await event.edit(f"❌ Gagal menghapus akun <code>{username}</code>.\nError: {e}", parse_mode="html", buttons=[
            [Button.inline("Kembali", b"back-to-main")]
        ])

@bot.on(events.CallbackQuery(data=b"cancel-delete"))
async def cancel_delete(event):
    await event.edit("❌ Penghapusan akun dibatalkan.", buttons=[
        [Button.inline("Kembali", b"back-to-main")]
    ])


#==========================
#== BUTTON BACK TO MAIN ===
#==========================
@bot.on(events.CallbackQuery(data=b"back-to-main"))
async def back_to_main(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
    await event.edit("📂 Kembali ke Menu Utama", buttons=None)
    await show_main_menu(event.chat_id)
