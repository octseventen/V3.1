from kyt import *
import asyncio
import subprocess
import time
import random
import datetime as DT
import os
import re
import requests
from telethon import events, Button

#MENU TRIAL
@bot.on(events.CallbackQuery(data=b"trial-ssh"))
async def trial_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond("🕐 Masukkan Durasi Trial (menit):")
        menit = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

    try:
        menit_int = int(menit)
        if menit_int <= 0 or menit_int > 1440:
            raise ValueError
    except:
        await event.respond("❌ Durasi harus angka (1–1440 menit).")
        return

    # Auto generate username & password
    rand_suffix = random.randint(1000, 9999)
    username = f"Trial-{rand_suffix}"
    password = "1"

    # Tanggal & expired
    now = DT.datetime.now()
    expired_time = now + DT.timedelta(minutes=menit_int)
    tgl_exp = expired_time.strftime("%H:%M:%S %d-%b-%Y")

    # Ambil domain & IP
    try:
        domain = open("/etc/xray/domain").read().strip()
        ipvps = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    except:
        domain = "unknown"
        ipvps = "0.0.0.0"

    try:
        subprocess.run(f"useradd -e {expired_time.strftime('%Y-%m-%d')} -s /bin/false -M {username}", shell=True, check=True)
        subprocess.run(f"echo '{username}:{password}' | chpasswd", shell=True, check=True)
    except Exception as e:
        await event.respond(f"❌ Gagal membuat akun `{username}`.\nError: {e}")
        return

    # Auto delete by at
    subprocess.run(f"echo 'userdel -f {username}' | at now + {menit_int} minutes", shell=True)

    # Simpan ke log database trial (opsional)
    with open("/etc/ssh/.ssh.db", "a") as f:
        f.write(f"#trial# {username} {password} {tgl_exp}\n")

    # Kirim laporan
    msg = f"""◇━━━━━━━━━━━━━━━━◇
 Trial SSH Account
◇━━━━━━━━━━━━━━━━◇
Username   : {username}
Password   : {password}
IP VPS     : {ipvps}
Domain     : {domain}
Ports      : 22, 80, 443, 109, 143, 1194, 2200
Aktif s/d  : {tgl_exp}
Durasi     : {menit_int} menit
◇━━━━━━━━━━━━━━━━◇"""

# Tombol kembali ke menu SSH
tombol_kembali = [
    [Button.inline("🔙 Kembali ke SSH Menu", b"ssh")]
]
    await event.respond(f"<code>{msg}</code>", buttons=tombol_kembali, parse_mode="html")
    

#CREATE SSH
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond("🧾 Masukkan Username:")
        username = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        # Validasi username
        if not re.match("^[a-zA-Z][a-zA-Z0-9_-]{2,15}$", username):
            await event.respond("❌ Username tidak valid. Harus diawali huruf, 3–16 karakter, hanya a-z, 0-9, -, _")
            return

        # Cek user sudah ada
        if subprocess.run(f"id -u {username}", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
            await event.respond(f"❌ Username `{username}` sudah terdaftar.")
            return

        await conv.send_message("🔐 Masukkan Password:")
        password = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("🌐 Limit IP Login:")
        iplimit = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("💾 Limit Kuota (GB):")
        quota_gb = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

        await conv.send_message("⏳ Masa aktif (hari):")
        aktif_hari = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

    await event.respond("⏳ Membuat akun, harap tunggu...")

    # Ambil domain dan IP
    try:
        with open("/etc/xray/domain", "r") as f:
            domain = f.read().strip()
        ipvps = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode().strip()
    except:
        domain = "unknown"
        ipvps = "0.0.0.0"

    now = DT.datetime.now()
    tgl_buat = now.strftime("%d %b %Y")
    tgl_exp = (now + DT.timedelta(days=int(aktif_hari))).strftime("%d %b %Y")
    expired_date = (now + DT.timedelta(days=int(aktif_hari))).strftime("%Y-%m-%d")

    # Buat user
    try:
        subprocess.run(f"useradd -e {expired_date} -s /bin/false -M {username}", shell=True, check=True)
    except subprocess.CalledProcessError as e:
        await event.respond(f"❌ Gagal membuat akun `{username}`.\nError: {e}")
        return

    # Set password pakai chpasswd
    try:
        subprocess.run(f"echo '{username}:{password}' | chpasswd", shell=True, check=True)
    except subprocess.CalledProcessError as e:
        subprocess.run(f"userdel -f {username}", shell=True)
        await event.respond(f"❌ Gagal mengatur password. Akun `{username}` dibatalkan.\nError: {e}")
        return

    # Simpan IP limit
    os.makedirs("/etc/kyt/limit/ssh/ip", exist_ok=True)
    if iplimit.isdigit() and int(iplimit) > 0:
        with open(f"/etc/kyt/limit/ssh/ip/{username}", "w") as f:
            f.write(iplimit)

    # Simpan quota
    try:
        quota_byte = int(quota_gb) * 1024 * 1024 * 1024
    except:
        quota_byte = 0

    if quota_byte > 0:
        os.makedirs("/etc/ssh", exist_ok=True)
        with open(f"/etc/ssh/{username}", "w") as f:
            f.write(str(quota_byte))

    # Auto delete
    subprocess.run(f"echo 'userdel -f {username}' | at now + {aktif_hari} days", shell=True)

    # Simpan ke database
    os.makedirs("/etc/ssh", exist_ok=True)
    subprocess.run(f"sed -i '/\\b{username}\\b/d' /etc/ssh/.ssh.db", shell=True)
    with open("/etc/ssh/.ssh.db", "a") as f:
        f.write(f"#ssh# {username} {password} {quota_gb} {iplimit} {tgl_exp}\n")

    # Format laporan lengkap
text = f"""◇━━━━━━━━━━━━━━━━━◇
 Format SSH OVPN Account
◇━━━━━━━━━━━━━━━━━◇
Username         : {username}
Password         : {password}
Limit IP         : {iplimit}
Limit Quota      : {quota_gb} GB
IP VPS           : {ipvps}
Domain           : {domain}
Port SSH         : 22, 80, 443
Dropbear         : 109, 143
SSL/TLS          : 443, 400-900
SSH WS           : 80, 8080, 8081-9999
SSH WS SSL       : 443
OVPN WS SSL      : 443
OVPN TCP         : 1194
OVPN UDP         : 2200
BadVPN UDP       : 7100, 7200, 7300
◇━━━━━━━━━━━━━━━━━◇
Aktif Selama     : {aktif_hari} Hari
Dibuat Pada      : {tgl_buat}
Berakhir Pada    : {tgl_exp}
◇━━━━━━━━━━━━━━━━━◇
OVPN Download    : https://{domain}:81/
Save Link        : https://{domain}:81/ssh-{username}.txt
"""

# Notifikasi singkat
notif = f"""✅ <b>Akun SSH berhasil dibuat</b>
👤 <b>Username</b>: <code>{username}</code>
🔑 <b>Password</b>: <code>{password}</code>
⏳ <b>Expired</b>: <code>{tgl_exp}</code>"""

# Tombol kembali ke menu SSH
tombol_kembali = [
    [Button.inline("🔙 Kembali ke SSH Menu", b"ssh")]
]

# Kirim notifikasi singkat dulu
await event.respond(notif, parse_mode="html")

# Jeda 3 detik
await asyncio.sleep(3)

# Kirim laporan detail + tombol kembali
await event.respond(f"<code>{text}</code>", buttons=tombol_kembali, parse_mode="html")

#MENU SSH
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh_menu(event):
    sender = await event.get_sender()

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    try:
        with open("/etc/xray/domain", "r") as f:
            domain = f.read().strip()
    except:
        domain = "domain.tidak.terdeteksi"
    msg = f"""
◇━━━━━━━━━━━━━━━━━━━━━━◇
   🇮🇩 <b>SSH/OPENVPN MENU</b> 🇮🇩
◇━━━━━━━━━━━━━━━━━━━━━━◇
🔰 <b>Service</b>: SSH & OVPN
🌐 <b>Hostname/IP</b>: <code>{domain}</code>
🏢 <b>ISP</b>: {z['isp']}
🌍 <b>Country</b>: {z['country']}
◇━━━━━━━━━━━━━━━━━━━━━━◇
"""

    tombol = [
        [Button.inline("⚡ TRIAL SSH", b"trial-ssh"), Button.inline("➕ CREATE SSH", b"create-ssh")],
        [Button.inline("❌ DELETE SSH", b"delete-ssh"), Button.inline("👀 CHECK LOGIN", b"login-ssh")],
        [Button.inline("📋 SHOW USER", b"show-ssh")],
        [Button.inline("🔙 Main Menu", b"menu")]
    ]

    await event.edit(msg, buttons=tombol, parse_mode="html")
